# Importing necessary modules from the Flask framework.
# - Flask is the main class that creates the web application instance.
# - render_template is used to render HTML templates.
# - request is used to handle incoming data from HTTP requests.
# - flash is used to display temporary messages to the user.
from flask import Flask, render_template, request, flash 

# Initialize the Flask application
app = Flask(__name__)

# Setting a secret key to allow flash messages (used for storing messages across requests)
app.secret_key = 'some_secret'  # Required for flash messages

# Define the route for the homepage ("/") and allow both GET and POST methods
@app.route('/', methods=['GET', 'POST'])
def index():
    # If the user submits the form (POST request)
    if request.method == 'POST':
        try:
            # Retrieve and convert the submitted "prelim_grade" to a float
            prelim_grade = float(request.form['prelim_grade'])
            
            # Validate that the prelim grade is between 0 and 100
            if not (0 <= prelim_grade <= 100):
                flash("Prelim grade must be between 0 and 100.")  # Show error message
            else:
                # If valid, calculate grades using the helper function and flash the result
                result = calculate_grades(prelim_grade)
                flash(result)
        except ValueError:
            # If the input is not a valid number, flash an error message
            flash("Please enter a valid number for Prelim grade.")

    # Render the HTML template (index.html) for both GET and POST requests
    return render_template('index.html')

# A helper function to calculate grades based on the prelim grade
def calculate_grades(prelim):
    passing_grade = 75  # Define the passing grade threshold
    
    # Calculate the maximum possible score from Midterm and Final grades
    max_midterm_final = 0.30 * 100 + 0.50 * 100  # Midterm (30%) and Final (50%)

    # If prelim grade is already at or above the passing grade
    if prelim >= passing_grade:
        return f"Prelim Grade: {prelim} You have passed the subject."
    
    # Calculate the minimum overall score needed to pass the subject
    required_overall_score = passing_grade - 0.20 * prelim  # 20% of the prelim grade is considered

    # Check if it's possible to pass based on the prelim grade
    if required_overall_score > max_midterm_final:
        return f"Prelim Grade: {prelim} It is difficult to pass with this grade."

        # Calculate required Midterm and Final grades to pass
    min_midterm_final = required_overall_score / 0.80
    midterm_grade_needed = (min_midterm_final * 0.30)
    final_grade_needed = (min_midterm_final * 0.50)

    # Calculate the minimum combined Midterm and Final grade needed to pass
    min_midterm_final = required_overall_score / 0.80  # 80% weight from Midterm and Final grades
    return f"Prelim Grade: {prelim} You need at least a combined Midterm and Final score of {min_midterm_final:.2f} to pass."

# Run the Flask application when the script is executed
if __name__ == '__main__':
    app.run(debug=True)  # Enable debug mode for easier troubleshooting during development
